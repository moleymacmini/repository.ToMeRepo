import xbmc
import xbmcaddon
from dudehere.routines import *
try:
	KODI_LANGUAGE = xbmc.getLanguage().lower()
except:
	KODI_LANGUAGE = 'english'
LANGUAGE_PATH = vfs.join(ROOT_PATH, 'resources/language/' + KODI_LANGUAGE)

def i18n(id):
	return xbmcaddon.Addon().getLocalizedString(id).encode('utf-8', 'ignore')