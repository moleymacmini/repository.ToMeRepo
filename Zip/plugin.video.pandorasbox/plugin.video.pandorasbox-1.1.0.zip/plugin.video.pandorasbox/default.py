# -*- coding: cp1252 -*-
if 64 - 64: i11iIiiIii
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
if 22 - 22: I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
if 48 - 48: oO0o / OOooOOo / I11i / Ii1I
if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * Ii1I
if 46 - 46: ooOoO0o * I11i - OoooooooOO
if 30 - 30: o0oOOo0O0Ooo - O0 % o0oOOo0O0Ooo - OoooooooOO * O0 * OoooooooOO
if 60 - 60: iIii1I11I1II1 / i1IIi * oO0o - I1ii11iIi11i + o0oOOo0O0Ooo
if 94 - 94: i1IIi % Oo0Ooo
if 68 - 68: Ii1I / O0
if 46 - 46: O0 * II111iiii / IiII * Oo0Ooo * iII111i . I11i
if 62 - 62: i11iIiiIii - II111iiii % I1Ii111 - iIii1I11I1II1 . I1ii11iIi11i . II111iiii
if 61 - 61: oO0o / OoOoOO00 / iII111i * OoO0O00 . II111iiii
if 1 - 1: II111iiii - I1ii11iIi11i % i11iIiiIii + IiII . I1Ii111
if 55 - 55: iIii1I11I1II1 - I1IiiI . Ii1I * IiII * i1IIi / iIii1I11I1II1
if 79 - 79: oO0o + I1Ii111 . ooOoO0o * IiII % I11i . I1IiiI
import sys
import urlparse
import urllib , urllib2 , datetime , re , os , base64 , xbmc , xbmcplugin , xbmcgui , xbmcaddon , xbmcvfs , traceback , cookielib , urlparse , httplib , time
import urlresolver
import time
import cloudflare , client , googleplus , cleantitle
if 94 - 94: iII111i * Ii1I / IiII . i1IIi * iII111i
iiiii11iII1 = xbmcgui . Dialog ( )
O0o = base64 . decodestring
oO0 = O0o ( 'LnBocA==' )
IIIi1i1I = ( O0o ( 'aHR0cDovL2dlbmlldHZjdW50cy5jby51ay9QYW5zQm94L09SSUdJTlMv' ) )
OOoOoo00oo = 'plugin.video.pandorasbox'
iiI11 = sys . argv [ 0 ]
OOooO = int ( sys . argv [ 1 ] )
OOoO00o = urlparse . parse_qs ( sys . argv [ 2 ] [ 1 : ] )
II111iiiiII = "Pandoras Box"
oOoOo00oOo = "1.0.1"
Oo = 'Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; AS; rv:11.0) like Gecko'
o00O00O0O0O = 'Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.0'
OooO0OO = 'Mozilla/5.0 (iPhone; CPU iPhone OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5376e Safari/8536.25'
iiiIi = 'Mozilla/5.0 (Linux; Android 4.4.2; Nexus 4 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.114 Mobile Safari/537.36'
if 24 - 24: O0 % o0oOOo0O0Ooo + i1IIi + I1Ii111 + I1ii11iIi11i
OOoO000O0OO = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , '' ) )
iiI1IiI = os . path . join ( OOoO000O0OO , OOoOoo00oo , 'resources' , 'art' ) + os . sep
II = xbmc . translatePath ( os . path . join ( OOoO000O0OO , OOoOoo00oo , 'fanart.jpg' ) )
if 57 - 57: oO0o
if 14 - 14: Oo0Ooo . I1IiiI / Ii1I
if 38 - 38: II111iiii % i11iIiiIii . ooOoO0o - OOooOOo + Ii1I
def Ooooo0Oo00oO0 ( ) :
 if 12 - 12: iIii1I11I1II1 * I1IiiI . ooOoO0o % I11i + O0
 O00 ( '[COLOR darkgoldenrod]Open Pandora\'s Box[/COLOR]' , '' , 400 , 'https://encrypted-tbn1.gstatic.com/images?q=tbn%3AANd9GcTQ9r4TA8yIw9ggxuwsHxWojo6tPVfgTe8QIOxOQwzNR2TavtCi6Q' , iiI1IiI + 'fanart.jpg' , '' )
 O00 ( '[COLOR darkgoldenrod]Search[/COLOR]' , '' , 1 , 'http://icons.iconarchive.com/icons/icontexto/search/256/search-red-dark-icon.png' , iiI1IiI + 'fanart.jpg' , '' )
 if 61 - 61: ooOoO0o
 xbmcplugin . setContent ( OOooO , 'movies' )
 if 79 - 79: Oo0Ooo + I1IiiI - iII111i
def oO00O00o0OOO0 ( url ) :
 Ii1iIIIi1ii = cloudflare . source ( url )
 o0oo0o0O00OO = re . compile ( '<li id=".+?">.+?<a href="(.+?)">.+?<img width="40" height="40" src="(.+?)" alt=""/>.+?<span class="title">\n(.+?)</span>.+?<span class="alt-title">\n(.+?)</span>.+?</a>.+?</li>' , re . DOTALL ) . findall ( Ii1iIIIi1ii )
 for url , o0oO , I1i1iii , i1iiI11I in o0oo0o0O00OO :
  O00 ( I1i1iii + '  -  ' + ( i1iiI11I ) . replace ( 'sezon' , 'Season' ) . replace ( 'bölüm' , 'Episode' ) , url , 3 , o0oO , '' , '' )
  if 29 - 29: OoooooooOO
  if 23 - 23: o0oOOo0O0Ooo . II111iiii
def Oo0O0OOOoo ( url ) :
 Ii1iIIIi1ii = cloudflare . source ( url )
 o0oo0o0O00OO = re . compile ( 'file: "(.+?)",.+?label: "(.+?)",' , re . DOTALL ) . findall ( Ii1iIIIi1ii )
 for url , I1i1iii in o0oo0o0O00OO :
  oOoOooOo0o0 ( I1i1iii , url , 10 , '' , '' , '' )
  if 61 - 61: o0oOOo0O0Ooo / OoO0O00 + ooOoO0o * oO0o / oO0o
 xbmcplugin . addSortMethod ( OOooO , xbmcplugin . SORT_METHOD_TITLE ) ;
 if 75 - 75: i1IIi / OoooooooOO - O0 / OoOoOO00 . II111iiii - i1IIi
 if 71 - 71: OOooOOo + Ii1I * OOooOOo - OoO0O00 * o0oOOo0O0Ooo
def Oooo0Ooo000 ( ) :
 O00 ( 'Search Pandoras Films' , '' , 424 , iiI1IiI + 'icon.png' , iiI1IiI + 'fanart.jpg' , '' )
 O00 ( 'Search Pandoras TV' , '' , 425 , iiI1IiI + 'icon.png' , iiI1IiI + 'fanart.jpg' , '' )
 if 51 - 51: i11iIiiIii . I1IiiI + II111iiii
 xbmcplugin . setContent ( OOooO , 'movies' )
 if 10 - 10: I1ii11iIi11i * ooOoO0o * II111iiii % Ii1I . OOooOOo + I1Ii111
 if 19 - 19: OoOoOO00 - I1IiiI . OOooOOo / IiII
def I11II ( ) :
 if 32 - 32: OoO0O00 * o0oOOo0O0Ooo
 Ii1iIIIi1ii = OOoO0O0o ( IIIi1i1I + O0o ( 'c3BvbmdlbWFpbi5waHA=' ) )
 o0oo0o0O00OO = re . compile ( '<item>.+?<title>(.+?)</title>.+?<description>(.+?)</description>.+?<link>(.+?)</link>.+?<thumbnail>(.+?)</thumbnail>.+?<fanart>(.+?)</fanart>.+?<mode>(.+?)</mode>.+?</item>' , re . DOTALL ) . findall ( Ii1iIIIi1ii )
 for I1i1iii , O0o0Ooo , O00iI1Ii11iII1 , o0oO , Oo0O0O0ooO0O , IIIIii in o0oo0o0O00OO :
  O00 ( I1i1iii , O00iI1Ii11iII1 , IIIIii , o0oO , Oo0O0O0ooO0O , O0o0Ooo )
  if 70 - 70: Ii1I / I11i . iII111i % Oo0Ooo
 xbmcplugin . setContent ( OOooO , 'movies' )
 if 67 - 67: OoOoOO00 * o0oOOo0O0Ooo . IiII - OoO0O00 * o0oOOo0O0Ooo
 if 46 - 46: OOooOOo + OoOoOO00 . I1IiiI * oO0o % IiII
def Oo000o ( url ) :
 if 7 - 7: ooOoO0o * OoO0O00 % oO0o . IiII
 xbmcplugin . addSortMethod ( handle = int ( sys . argv [ 1 ] ) , sortMethod = xbmcplugin . SORT_METHOD_TITLE )
 Ii1iIiII1ii1 = OOoO0O0o ( url )
 o0oo0o0O00OO = re . compile ( '<a href="(.+?)" target="_blank"><img src="(.+?)" style="max-width:200px;" /><description = "(.+?)" /><background = "(.+?)" </background></a><br><b>(.+?)</b>' ) . findall ( Ii1iIiII1ii1 )
 for url , ooOooo000oOO , O0o0Ooo , Oo0oOOo , I1i1iii in o0oo0o0O00OO :
  oOoOooOo0o0 ( I1i1iii , url , 401 , ooOooo000oOO , Oo0oOOo , O0o0Ooo )
  if 58 - 58: II111iiii * OOooOOo * I1ii11iIi11i / OOooOOo
  xbmcplugin . setContent ( OOooO , 'movies' )
  xbmcplugin . addSortMethod ( OOooO , xbmcplugin . SORT_METHOD_TITLE ) ;
  if 75 - 75: oO0o
def I1III ( ) :
 if 63 - 63: OOooOOo % oO0o * oO0o * OoO0O00 / I1ii11iIi11i
 o0ooO = iiiii11iII1 . input ( 'Search' , type = xbmcgui . INPUT_ALPHANUM )
 O0o0O00Oo0o0 = o0ooO . lower ( )
 O00O0oOO00O00 = [ '480p' , '720p' , '1080p' , 'mova' , 'movb' , 'movc' , 'movd' , 'move' , 'movf' , 'movg' , 'movh' , 'movi' , 'movj' , 'movk' , 'movl' , 'movm' , 'movn' , 'movo' , 'movp' , 'movq' , 'movr' , 'movs' , 'movt' , 'movu' , 'movv' , 'movw' , 'movx' , 'movy' , 'movz' ]
 if 11 - 11: IiII . I1ii11iIi11i
 for o0 in O00O0oOO00O00 :
  oo0oOo = IIIi1i1I + o0 + oO0
  o000O0o = OOoO0O0o ( oo0oOo )
  o0oo0o0O00OO = re . compile ( '<a href="(.+?)" target="_blank"><img src="(.+?)" style="max-width:200px;" /><description = "(.+?)" /><background = "(.+?)" </background></a><br><b>(.+?)</b>' ) . findall ( o000O0o )
  for O00iI1Ii11iII1 , ooOooo000oOO , O0o0Ooo , Oo0O0O0ooO0O , I1i1iii in o0oo0o0O00OO :
   if o0ooO in I1i1iii . lower ( ) :
    oOoOooOo0o0 ( I1i1iii , O00iI1Ii11iII1 , 401 , ooOooo000oOO , Oo0O0O0ooO0O , O0o0Ooo )
    if 42 - 42: OoOoOO00
    xbmcplugin . setContent ( OOooO , 'movies' )
    xbmcplugin . addSortMethod ( OOooO , xbmcplugin . SORT_METHOD_TITLE ) ;
    if 41 - 41: Oo0Ooo . ooOoO0o + O0 * o0oOOo0O0Ooo % Oo0Ooo * Oo0Ooo
    if 19 - 19: iII111i
def IIi1iiIi1 ( ) :
 if 21 - 21: I1IiiI * iIii1I11I1II1
 o0ooO = iiiii11iII1 . input ( 'Search' , type = xbmcgui . INPUT_ALPHANUM )
 O0o0O00Oo0o0 = o0ooO . lower ( )
 O00O0oOO00O00 = [ 'a' , 'b' , 'c' , 'd' , 'e' , 'f' , 'g' , 'h' , 'i' , 'j' , 'k' , 'l' , 'm' , 'n' , 'o' , 'p' , 'q' , 'r' , 's' , 't' , 'u' , 'v' , 'w' , 'x' , 'y' , 'z' ]
 if 91 - 91: IiII
 for o0 in O00O0oOO00O00 :
  iiIii = IIIi1i1I + o0 + oO0
  o000O0o = OOoO0O0o ( iiIii )
  o0oo0o0O00OO = re . compile ( '<item>.+?<title>(.+?)</title>.+?<description>(.+?)</description>.+?<link>(.+?)</link>.+?<thumbnail>(.+?)</thumbnail>.+?<fanart>(.+?)</fanart>.+?<mode>(.+?)</mode>.+?</item>' , re . DOTALL ) . findall ( o000O0o )
  for I1i1iii , O0o0Ooo , O00iI1Ii11iII1 , o0oO , Oo0O0O0ooO0O , IIIIii in o0oo0o0O00OO :
   if o0ooO in I1i1iii . lower ( ) :
    O00 ( I1i1iii , O00iI1Ii11iII1 , IIIIii , o0oO , Oo0O0O0ooO0O , O0o0Ooo )
    if 79 - 79: OoooooooOO / O0
    xbmcplugin . setContent ( OOooO , 'movies' )
    xbmcplugin . addSortMethod ( OOooO , xbmcplugin . SORT_METHOD_TITLE ) ;
    if 75 - 75: OoOoOO00 % o0oOOo0O0Ooo % o0oOOo0O0Ooo . I1Ii111
    if 5 - 5: o0oOOo0O0Ooo * ooOoO0o + OoOoOO00 . OOooOOo + OoOoOO00
def oO ( url ) :
 if 7 - 7: o0oOOo0O0Ooo - I1IiiI
 Ii1iIIIi1ii = OOoO0O0o ( url )
 o0oo0o0O00OO = re . compile ( '<item>.+?<title>(.+?)</title>.+?<description>(.+?)</description>.+?<link>(.+?)</link>.+?<thumbnail>(.+?)</thumbnail>.+?<fanart>(.+?)</fanart>.+?<mode>(.+?)</mode>.+?</item>' , re . DOTALL ) . findall ( Ii1iIIIi1ii )
 for I1i1iii , O0o0Ooo , url , o0oO , Oo0O0O0ooO0O , IIIIii in o0oo0o0O00OO :
  O00 ( I1i1iii , url , IIIIii , o0oO , Oo0O0O0ooO0O , O0o0Ooo )
  if 100 - 100: oO0o + I11i . OOooOOo * Ii1I
  xbmcplugin . setContent ( OOooO , 'movies' )
  xbmcplugin . addSortMethod ( OOooO , xbmcplugin . SORT_METHOD_TITLE ) ;
  if 73 - 73: i1IIi + I1IiiI
def oOoOooOo0o0 ( name , url , mode , iconimage , fanart , description ) :
 if 46 - 46: OoO0O00 . Oo0Ooo - OoooooooOO
 ooo00OOOooO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 O00OOOoOoo0O = True
 O000OOo00oo = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 O000OOo00oo . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 O000OOo00oo . setProperty ( "Fanart_Image" , fanart )
 O00OOOoOoo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = ooo00OOOooO , listitem = O000OOo00oo , isFolder = False )
 return O00OOOoOoo0O
 if 71 - 71: i11iIiiIii + IiII
def O00 ( name , url , mode , iconimage , fanart , description ) :
 if 57 - 57: oO0o . I11i . i1IIi
 ooo00OOOooO = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 O00OOOoOoo0O = True
 O000OOo00oo = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 O000OOo00oo . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 O000OOo00oo . setProperty ( "Fanart_Image" , fanart )
 O00OOOoOoo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = ooo00OOOooO , listitem = O000OOo00oo , isFolder = True )
 return O00OOOoOoo0O
 if 42 - 42: I11i + I1ii11iIi11i % O0
 if 6 - 6: oO0o
def oOOo0oOo0 ( ) :
 IIooooo = [ ]
 II1I = sys . argv [ 2 ]
 if len ( II1I ) >= 2 :
  O0i1II1Iiii1I11 = sys . argv [ 2 ]
  IIII = O0i1II1Iiii1I11 . replace ( '?' , '' )
  if ( O0i1II1Iiii1I11 [ len ( O0i1II1Iiii1I11 ) - 1 ] == '/' ) :
   O0i1II1Iiii1I11 = O0i1II1Iiii1I11 [ 0 : len ( O0i1II1Iiii1I11 ) - 2 ]
  iiIiI = IIII . split ( '&' )
  IIooooo = { }
  for o00oooO0Oo in range ( len ( iiIiI ) ) :
   o0O0OOO0Ooo = { }
   o0O0OOO0Ooo = iiIiI [ o00oooO0Oo ] . split ( '=' )
   if ( len ( o0O0OOO0Ooo ) ) == 2 :
    IIooooo [ o0O0OOO0Ooo [ 0 ] ] = o0O0OOO0Ooo [ 1 ]
    if 45 - 45: O0 / o0oOOo0O0Ooo
 return IIooooo
 if 32 - 32: iII111i . IiII . IiII
O0i1II1Iiii1I11 = oOOo0oOo0 ( )
O00iI1Ii11iII1 = None
I1i1iii = None
ooOooo000oOO = None
IIIIii = None
OO00O0O = None
if 33 - 33: O0 . IiII . I1IiiI
if 72 - 72: i1IIi / OoO0O00 + OoooooooOO - Oo0Ooo
try :
 O00iI1Ii11iII1 = urllib . unquote_plus ( O0i1II1Iiii1I11 [ "url" ] )
except :
 pass
try :
 I1i1iii = urllib . unquote_plus ( O0i1II1Iiii1I11 [ "name" ] )
except :
 pass
try :
 ooOooo000oOO = urllib . unquote_plus ( O0i1II1Iiii1I11 [ "iconimage" ] )
except :
 pass
try :
 IIIIii = int ( O0i1II1Iiii1I11 [ "mode" ] )
except :
 pass
try :
 Oo0O0O0ooO0O = urllib . unquote_plus ( O0i1II1Iiii1I11 [ "fanart" ] )
except :
 pass
try :
 OO00O0O = urllib . unquote_plus ( O0i1II1Iiii1I11 [ "description" ] )
except :
 pass
 if 29 - 29: I1ii11iIi11i + oO0o % O0
 if 10 - 10: I11i / I1Ii111 - I1IiiI * iIii1I11I1II1 - I1IiiI
print str ( II111iiiiII ) + ': ' + str ( oOoOo00oOo )
print "Mode: " + str ( IIIIii )
print "URL: " + str ( O00iI1Ii11iII1 )
print "Name: " + str ( I1i1iii )
print "IconImage: " + str ( ooOooo000oOO )
if 97 - 97: I1ii11iIi11i + I1IiiI * Ii1I + OOooOOo % iII111i
def OOOOOoo0 ( ) :
 try :
  ii1 = getSet ( "core-player" )
  if ( ii1 == 'DVDPLAYER' ) : I1iI1iIi111i = xbmc . PLAYER_CORE_DVDPLAYER
  elif ( ii1 == 'MPLAYER' ) : I1iI1iIi111i = xbmc . PLAYER_CORE_MPLAYER
  elif ( ii1 == 'PAPLAYER' ) : I1iI1iIi111i = xbmc . PLAYER_CORE_PAPLAYER
  else : I1iI1iIi111i = xbmc . PLAYER_CORE_AUTO
 except : I1iI1iIi111i = xbmc . PLAYER_CORE_AUTO
 return I1iI1iIi111i
 return True
 if 44 - 44: i1IIi % II111iiii + I11i
def I1I1I ( url ) :
 OoOO000 = xbmc . Player ( OOOOOoo0 ( ) )
 import urlresolver
 try : OoOO000 . play ( url )
 except : pass
 if 14 - 14: IiII - I1ii11iIi11i
 if 11 - 11: II111iiii * II111iiii % iIii1I11I1II1 * I1Ii111 + OoOoOO00 / I1IiiI
 if 3 - 3: o0oOOo0O0Ooo
def Ii11I1 ( url ) :
 OoOO000 = xbmc . Player ( OOOOOoo0 ( ) )
 import urlresolver
 try : OoOO000 . play ( url )
 except : pass
 from urlresolver import common
 i1i1Iiii1I1 = xbmcgui . DialogProgress ( )
 i1i1Iiii1I1 . create ( 'LOADING' , 'Opening %s Now' % ( I1i1iii ) )
 OoOO000 = xbmc . Player ( OOOOOoo0 ( ) )
 url = urlresolver . HostedMediaFile ( url ) . resolve ( )
 if i1i1Iiii1I1 . iscanceled ( ) :
  print "[COLORred]STREAM CANCELLED[/COLOR]"
  oooO0 = xbmcgui . Dialog ( )
  if oooO0 . yesno ( "[B]CANCELLED[/B]" , '[B]Was There A Problem[/B]' , '' , "" , 'Yes' , 'No' ) :
   oooO0 . ok ( "Message Send" , "Your Message Has Been Sent" )
  else :
   return
 else :
  try : OoOO000 . play ( url )
  except : pass
  try : ADDON . resolve_url ( url )
  except : pass
  i1i1Iiii1I1 . close ( )
  if 46 - 46: I1Ii111
def OOoO0O0o ( url ) :
 oooOOoOO = urllib2 . Request ( url )
 Oo = 'Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; AS; rv:11.0) like Gecko'
 o00O00O0O0O = 'Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.0'
 OooO0OO = 'Mozilla/5.0 (iPhone; CPU iPhone OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5376e Safari/8536.25'
 iiiIi = 'Mozilla/5.0 (Linux; Android 4.4.2; Nexus 4 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.114 Mobile Safari/537.36'
 oooOOoOO . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
 IIOOOO0oo0 = urllib2 . urlopen ( oooOOoOO )
 Ii1iIiII1ii1 = IIOOOO0oo0 . read ( )
 IIOOOO0oo0 . close ( )
 return Ii1iIiII1ii1
 if 35 - 35: Ii1I - I1IiiI % o0oOOo0O0Ooo . OoooooooOO % Ii1I
def I1i1Iiiii ( content , viewType ) :
 if content :
  xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , content )
  if 94 - 94: o0oOOo0O0Ooo * Ii1I / Oo0Ooo / Ii1I
  if 87 - 87: Oo0Ooo . IiII
if IIIIii == None : Ooooo0Oo00oO0 ( )
elif IIIIii == 1 : Oooo0Ooo000 ( )
elif IIIIii == 20 : oO00O00o0OOO0 ( O00iI1Ii11iII1 )
elif IIIIii == 3 : Oo0O0OOOoo ( O00iI1Ii11iII1 )
elif IIIIii == 10 : I1I1I ( O00iI1Ii11iII1 )
elif IIIIii == 400 : I11II ( )
elif IIIIii == 401 : Ii11I1 ( O00iI1Ii11iII1 )
elif IIIIii == 423 : oO ( O00iI1Ii11iII1 )
elif IIIIii == 424 : I1III ( )
elif IIIIii == 425 : IIi1iiIi1 ( )
elif IIIIii == 426 : Oo000o ( O00iI1Ii11iII1 )
elif IIIIii == 427 : oOoOooOo0o0 ( I1i1iii , O00iI1Ii11iII1 , IIIIii , ooOooo000oOO , Oo0O0O0ooO0O , OO00O0O )
if 75 - 75: ooOoO0o + OoOoOO00 + o0oOOo0O0Ooo * I11i % oO0o . iII111i
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
