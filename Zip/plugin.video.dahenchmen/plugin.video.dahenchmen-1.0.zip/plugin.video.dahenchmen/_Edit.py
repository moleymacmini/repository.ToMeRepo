import xbmcaddon

MainBase = 'http://dahenchmen.xyz/01/D4Henchm3n/DHlist.txt'
addon = xbmcaddon.Addon('plugin.video.dahenchmen')